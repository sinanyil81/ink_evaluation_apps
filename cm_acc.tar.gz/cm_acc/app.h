
#ifndef CM_FK_APP_H_
#define CM_FK_APP_H_

#include "ink.h"

// define task priorities
#define THREAD1 40
#define THREAD2 30
#define THREAD4 10
#define THREAD3 50

#endif /* CM_FK_APP_H_ */


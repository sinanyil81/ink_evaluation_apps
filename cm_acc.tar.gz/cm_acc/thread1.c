#include "app.h"
#include "ink.h"
#include "app_intrinsics.h"

// define task-shared persistent variables.

 __shared(
     uint8_t x,y;
 )

__USE_CHANNEL(THREAD1,THREAD2);

ENTRY_TASK(task1);


// called at the very first boot
void thread1_init(){
    // create a thread with priority 15 and entry task task1
    __CREATE(THREAD1,task1);
    __SIGNAL(THREAD1);
}


ENTRY_TASK(task1){

    P1IE |= BIT4;                               // P1.4 interrupt enabled
    P1IE |= BIT2;                              // P1.2 interrupt enabled
  __delay_cycles(15);
  // P1.3 will be the input to fire ISR2
  //enable_P1P4();


    return NULL;
}

isr_event_t timer_event;


_interrupt(PORT1_VECTOR)
{
  switch(__even_in_range(P1IV, P1IV_P1IFG7))
    {
        case P1IV_NONE:    break;                   // Vector  0:  No interrupt
        case P1IV_P1IFG0:  break;                   // Vector  2:  P1.0 interrupt flag
        case P1IV_P1IFG1:  break;                   // Vector  4:  P1.1 interrupt flag
        case P1IV_P1IFG2:
            P1IE = 0;                               // interrupt disable
            P1IFG &= ~BIT2;                         // Clear P1.2 IFG
            P3OUT |= BIT0;
            if (valid_signal())
            {
              if(!__EVENT_BUFFER_FULL(THREAD4))
              {
                timer_event.data = NULL;
                timer_event.size = 0;
                timer_event.timestamp = 2;

                //__SIGNAL_EVENT(THREAD4,&timer_event);
              }
              __SIGNAL(THREAD4);
            }
            /* turn on CPU */
            __bic_SR_register_on_exit(LPM3_bits);
            break;                                  // Vector  6:  P1.2 interrupt flag
        case P1IV_P1IFG3:  break;                   // Vector  8:  P1.3 interrupt flag
        case P1IV_P1IFG5:  break;                   // Vector  12:  P1.5 interrupt flag
        case P1IV_P1IFG4:                           // Vector  10:  P1.4 interrupt flag
            P1IE = 0;                               // interrupt disable
            P1IFG &= ~BIT4;                         // Clear P1.4 IFG
            P3OUT |= BIT5;
            if(!__EVENT_BUFFER_FULL(THREAD2))
            {
              timer_event.data = NULL;
              timer_event.size = 0;
              timer_event.timestamp = 1;

              //__SIGNAL_EVENT(THREAD2,&timer_event);
            }
            __SIGNAL(THREAD2);
            /* turn on CPU */
            __bic_SR_register_on_exit(LPM3_bits);
            break;
        case P1IV_P1IFG6:  break;          // Vector  14:  P1.6 interrupt flag
        case P1IV_P1IFG7:  break;          // Vector  16:  P1.7 interrupt flag
        default: break;
    }
 	  
}

